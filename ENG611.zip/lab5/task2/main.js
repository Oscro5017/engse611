//alert('hello');
var age =30;
console.log(age);
