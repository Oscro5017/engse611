const user = 'Brad';
console.log(user);
