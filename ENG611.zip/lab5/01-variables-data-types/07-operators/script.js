console.log(1+2*2-3);
// + -
// * /
// div mod 
// ()
console.log( (1+2)*2-3);

console.log(6%2);

console.log( 1!= 99999999999999999999 );

console.log( 2== '2' );//convert to same type
console.log( 2=== '2' );//not convert to same type

if ( 2== '2' ) console.log("Ok");


if (!( 2=== '2' )) console.log("Not tobe Ok");


if (true && true ) console.log("ok");

if (true || true) console.log("Ok");

if ((1=='1') && (3=='3')) 
    console.log("ok");
else
    console.log("not ok");

