let name;
let surname;

let Surname;
let cats=["Cherry", "Joss"];


let schoolname;
let school_name;


let mySchoolName;
let my_name;

my_name = "Supachok"; //Assignment Statement

console.log(my_name);

let a=1;
let b=2;
let c=1.3;

console.log(a, typeof a );
console.log(b, typeof b );
console.log(c, typeof c );

let bigNumber=1000000000000n;
console.log(bigNumber, typeof bigNumber);

console.log(cats, typeof cats);

let is_deleted = false;

console.log(is_deleted, typeof is_deleted);

a=1;
console.log(a, typeof a);

a = "1"; //re-assign to string value
console.log(a, typeof a);
a= a+1;
console.log(a , typeof a);

b=2;
console.log(b, typeof b);

const arr = [10, 20, 30, 40];
console.log(arr);

arr.push(50);
console.log(arr);

arr.pop();
console.log(arr);

const person = {
    name: 'Brad',
    email: 'brad@gmail.com'
};
console.log(person);

person.name = "John";
person.email = 'john@gmail.com';
console.log(person);