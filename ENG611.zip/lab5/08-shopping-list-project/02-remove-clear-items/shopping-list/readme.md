# Shopping List

Simple shopping list app from my Modern JS From The Beginning course.
