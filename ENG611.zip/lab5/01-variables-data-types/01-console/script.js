console.log("Hello world.");
console.log("answer: "+30.12+9.123);
const cat="cherry";
let dog;
dog = "Joey"
console.log(cat);
console.log(dog);
